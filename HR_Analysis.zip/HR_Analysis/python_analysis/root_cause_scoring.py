"""
HR Project Phase 3 — Root Cause Scoring
Identify the primary reason each resigned employee left
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
df = pd.read_csv(r'D:\Project\HR_analysis\HR_Attrition_clean.csv')

# Filter to resigned employees only
resigned = df[df['Attrition'] == 'Yes'].copy()

print(f"Total resigned employees: {len(resigned)}")
print("\n" + "="*60)

# ============================================================================
# BLOCK 1: Identify primary drivers for each resigned employee
# ============================================================================

def assign_primary_driver(row):
    """
    Assign the PRIMARY reason an employee likely resigned
    Based on comparison to company averages for active employees
    """
    active = df[df['Attrition'] == 'No']
    
    drivers = {}
    
    # 1. Low salary driver
    avg_salary = active['MonthlyIncome'].mean()
    if row['MonthlyIncome'] < avg_salary * 0.8:  # Earned 20% below average
        drivers['Low Salary'] = 1
    
    # 2. Overtime burnout driver
    if row['OverTime'] == 'Yes':
        drivers['Overtime Burnout'] = 1
    
    # 3. No growth/promotion driver
    avg_years_promotion = active['YearsSinceLastPromotion'].mean()
    if row['YearsSinceLastPromotion'] > avg_years_promotion:
        drivers['No Growth'] = 1
    
    # 4. Poor satisfaction driver
    avg_job_sat = active['JobSatisfaction'].mean()
    if row['JobSatisfaction'] < avg_job_sat:
        drivers['Poor Culture'] = 1
    
    # 5. Short tenure (didn't fit) driver
    if row['YearsAtCompany'] <= 2:
        drivers['Early Exit'] = 1
    
    # If no driver triggered, default to 'Other'
    if not drivers:
        return 'Other'
    
    # Return the driver with highest weight (if tie, return first)
    return list(drivers.keys())[0]

resigned['PrimaryDriver'] = resigned.apply(assign_primary_driver, axis=1)

# Count breakdown
driver_counts = resigned['PrimaryDriver'].value_counts()
print("\nRESIGNED EMPLOYEES BY PRIMARY DRIVER:")
print(driver_counts)
print(f"\nPercentage breakdown:")
print((driver_counts / len(resigned) * 100).round(1))

# ============================================================================
# BLOCK 2: Department-level root cause analysis
# ============================================================================

print("\n" + "="*60)
print("ROOT CAUSE BY DEPARTMENT:\n")

for dept in df['Department'].unique():
    dept_resigned = resigned[resigned['Department'] == dept]
    total = len(df[df['Department'] == dept])
    attrition_rate = len(dept_resigned) / total * 100
    
    print(f"\n{dept.upper()}")
    print(f"  Resignation Rate: {attrition_rate:.1f}% ({len(dept_resigned)}/{total})")
    
    # Top drivers in this department
    drivers = dept_resigned['PrimaryDriver'].value_counts()
    for driver, count in drivers.head(2).items():
        pct = count / len(dept_resigned) * 100
        print(f"  - {driver}: {count} employees ({pct:.0f}%)")

# ============================================================================
# BLOCK 3: Job Role analysis
# ============================================================================

print("\n" + "="*60)
print("HIGHEST-RISK JOB ROLES:\n")

role_risk = df.groupby('JobRole').apply(
    lambda x: {
        'total': len(x),
        'resigned': len(x[x['Attrition'] == 'Yes']),
        'attrition_rate': len(x[x['Attrition'] == 'Yes']) / len(x) * 100
    }
).apply(pd.Series).sort_values('attrition_rate', ascending=False)

for role in role_risk.head(5).index:
    role_resigned = resigned[resigned['JobRole'] == role]
    if len(role_resigned) > 0:
        print(f"\n{role}")
        print(f"  Attrition Rate: {role_risk.loc[role, 'attrition_rate']:.1f}%")
        drivers = role_resigned['PrimaryDriver'].value_counts()
        for driver, count in drivers.head(2).items():
            pct = count / len(role_resigned) * 100
            print(f"  - {driver}: {pct:.0f}%")

# ============================================================================
# BLOCK 4: Create summary statistics
# ============================================================================

print("\n" + "="*60)
print("TYPICAL RESIGNED EMPLOYEE PROFILE:\n")

active = df[df['Attrition'] == 'No']

print(f"Age: {resigned['Age'].mean():.0f} years (vs {active['Age'].mean():.0f} for active)")
print(f"Salary: ${resigned['MonthlyIncome'].mean():,.0f}/mo (vs ${active['MonthlyIncome'].mean():,.0f})")
print(f"Years at company: {resigned['YearsAtCompany'].mean():.1f} (vs {active['YearsAtCompany'].mean():.1f})")
print(f"Years in current role: {resigned['YearsInCurrentRole'].mean():.1f} (vs {active['YearsInCurrentRole'].mean():.1f})")
print(f"Years since promotion: {resigned['YearsSinceLastPromotion'].mean():.1f} (vs {active['YearsSinceLastPromotion'].mean():.1f})")
print(f"Job Satisfaction: {resigned['JobSatisfaction'].mean():.2f} (vs {active['JobSatisfaction'].mean():.2f})")
print(f"Overtime: {(resigned['OverTime'] == 'Yes').sum() / len(resigned) * 100:.0f}% (vs {(active['OverTime'] == 'Yes').sum() / len(active) * 100:.0f}%)")

# ============================================================================
# BLOCK 5: Visualizations
# ============================================================================

# Chart 1: Driver breakdown
plt.figure(figsize=(10, 6))
driver_counts.plot(kind='barh', color=['#E24B4A', '#EF9F27', '#378ADD', '#1D9E75', '#534AB7'])
plt.title('Resigned Employees by Primary Driver', fontsize=14, fontweight='bold')
plt.xlabel('Number of Employees')
for i, (driver, count) in enumerate(driver_counts.items()):
    pct = count / len(resigned) * 100
    plt.text(count + 1, i, f'{count} ({pct:.0f}%)', va='center', fontweight='bold')
plt.tight_layout()
plt.savefig(r'D:\Project\HR_analysis\chart8_drivers.png', dpi=150)
plt.show()

# Chart 2: Department breakdown by driver
dept_driver = pd.crosstab(resigned['Department'], resigned['PrimaryDriver'])
dept_driver.plot(kind='bar', stacked=True, figsize=(10, 6),
                 color=['#E24B4A', '#EF9F27', '#378ADD', '#1D9E75', '#534AB7'])
plt.title('Resignation Drivers by Department', fontsize=14, fontweight='bold')
plt.xlabel('Department')
plt.ylabel('Number of Employees')
plt.legend(title='Primary Driver', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(r'D:\Project\HR_analysis\chart9_dept_drivers.png', dpi=150)
plt.show()

# ============================================================================
# BLOCK 6: Export resigned employee list with drivers
# ============================================================================

export_cols = ['EmployeeNumber', 'Department', 'JobRole', 'MonthlyIncome', 
               'Age', 'YearsAtCompany', 'OverTime', 'JobSatisfaction', 'PrimaryDriver']

resigned_export = resigned[export_cols].sort_values('Department')
resigned_export.to_csv(r'D:\Project\HR_analysis\resigned_employees_with_drivers.csv', index=False)

print("\n" + "="*60)
print("✓ Export saved: resigned_employees_with_drivers.csv")
print("="*60)